package com.example.moonh_000.twodimensionforall;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by moonh_000 on 2018-03-06. 1714-192
 */

public class InitialLoad extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.initialload_screen);

        /*
        Create Splash Screen.
         */
        Thread mainThread = new Thread() {

            @Override
            public void run() {
                try {
                    super.run();
                    sleep(5000);
                } catch (Exception e) {

                } finally {
                    Intent i = new Intent(InitialLoad.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        };
        mainThread.start();
    }
}
