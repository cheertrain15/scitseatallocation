package com.example.moonh_000.twodimensionforall;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by moonh_000 on 2018-03-04.
 */

public class SubActivity extends AppCompatActivity{

    WebView videoView;
    URL url;
    HttpURLConnection connection;
    String videoPath; //Url of videofile from MainActivity.java.
    int videoNum; // The number of current video.
    String modifiedVideoNum;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_screen);

        /*
        Get the path of videofile from the previous intent.
         */
        videoPath = getIntent().getStringExtra("videoPath");
        modifiedVideoNum = "videoNum="+getIntent().getStringExtra("videoNum");
        /*
        Configure the settings of videoView(WebView).
         */
        videoView = findViewById(R.id.videoView);
        registerForContextMenu(videoView); //Enable Context Menu
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); // Hide status bar of the device.
        WebSettings videoViewSettings = videoView.getSettings();
        videoViewSettings.setJavaScriptEnabled(true);
        videoViewSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        videoView.setWebChromeClient(new WebChromeClient());
        videoView.setWebViewClient(new WebViewClient());
        videoView.loadUrl(videoPath);

        /*
        Adding the videoPath to the user's history DB.
         */
        addHistory();
    }

    /*
    Context Menu for videoView
     */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        /*
        Copy the link of the video to system clipboard.
         */
        menu.add(0,1,0,"Copy the link");
        /*
        When menu pops up, the device vibrates.
         */
        Vibrator clipVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        clipVibrator.vibrate(500);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        /*
        When "Copy the link" is pressed, the link will be copied to the system clipboard.
         */
        if(item.getItemId() == 1){
            ClipboardManager videoClipBoard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData videoClip = ClipData.newPlainText("The video Clip", videoPath);
            videoClipBoard.setPrimaryClip(videoClip);
            Toast.makeText(SubActivity.this,"The link is copied.",Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }


    /*
    Add user's HISTORY
     */
    public void addHistory(){
        try{
            url = new URL("http://10.10.17.236:9898/enjoy/addHistory");
        } catch (MalformedURLException e){
        }

        try{
            connection = (HttpURLConnection)url.openConnection();
            if(connection != null){
                connection.setConnectTimeout(5000);
                connection.setUseCaches(false);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Accept-Charset","UTF-8");
                connection.setRequestProperty("Context_Type","application/x-www-form-urlencoded;charset=UTF-8");

                OutputStream os = connection.getOutputStream();
                os.write(modifiedVideoNum.getBytes("UTF-8"));
                os.flush();
                os.close();

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";
                    while ((line = reader.readLine()) != null){
                        page += line;
                    }

                    Toast.makeText(this,page,Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e){

        } finally {
            if(connection!=null){
                connection.disconnect();
            }
        }
    }


    /*
    Terminate the activity when BACK button is pressed
     */
    @Override
    public void onBackPressed() {
        finish();
    }

}
