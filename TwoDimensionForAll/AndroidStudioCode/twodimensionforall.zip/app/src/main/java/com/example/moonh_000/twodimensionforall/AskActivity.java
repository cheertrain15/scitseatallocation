package com.example.moonh_000.twodimensionforall;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by moonh_000 on 2018-03-06.
 */

public class AskActivity extends AppCompatActivity{

    String id;
    EditText title, message;
    Button buttonSend;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ask_screen);
        id =  Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        title = findViewById(R.id.title);
        message = findViewById(R.id.message);
        buttonSend = findViewById(R.id.buttonSend);
    }

    /*
    Send an Email when 'Send' button is clicked.
     */
    public void send(View view){
        Vibrator clipVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        clipVibrator.vibrate(500);
        sendEmail();
    }

    /*
    The process of sending Email.
     */
    protected void sendEmail() {
        String[] TO = {"cheertrain15@naver.com"};
        String[] CC = {"Device ID : "+id};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, title.getText().toString());
        emailIntent.putExtra(Intent.EXTRA_TEXT, message.getText().toString());

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail by..."));
            finish();
            Log.i("Finished sending email", "!");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(AskActivity.this,
                    "Email client is not selected.", Toast.LENGTH_SHORT).show();
        }
    }
}
