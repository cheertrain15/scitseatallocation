package com.example.moonh_000.twodimensionforall;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.StrictMode;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    EditText searchText;
    LinearLayout list;
    URL url;
    HttpURLConnection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        searchText = findViewById(R.id.searchText);
        list = findViewById(R.id.list);

        /*
        If there is no ID in the members DB,
        register the current divice's ID to members DB automatically.
         */
        checkingId();

        /*
        ACTIVATE MENU
         */
        registerForContextMenu(list);

        /*
        ACTIVATE SEARCH FUNCTION
         */
        search();

        /*
        ACTIVATE LOADING ALL CLIPS.
         */
        loadAllVideo();

    }

    /*
   CONTEXT MENU
    */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
            if(v == list){
                menu.setHeaderTitle("Menu");
                menu.add(0,1,0,"View all clips");
                menu.add(0,2,0,"View my bookmark");
                menu.add(0,3,0,"View my history");
                SubMenu genre = menu.addSubMenu(0,4,0,"View by genre");
                genre.add(0,6,0,"Drama");
                genre.add(0,7,0,"Animation");
                menu.add(0,5,0,"Ask question");
                Vibrator clipVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                clipVibrator.vibrate(300);
            }
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getItemId() == 1){
            //View All Clips
            loadAllVideo();
            return true;
        } else if(item.getItemId() == 2){
            //View Bookmark
            bookMark();
            return true;
        } else if(item.getItemId() == 3){
            //View History
            history();
            return true;
        } else if (item.getItemId() == 4){
            //View By Genre
            return true;
        } else if(item.getItemId() == 5){
            //Show new view for asking question
            Intent intent = new Intent(MainActivity.this, AskActivity.class);
            startActivity(intent);
        } else if (item.getItemId() == 6){
            genre("videoGenre=Drama");
            return true;
        } else if (item.getItemId() == 7){
            genre("videoGenre=Animation");
            return true;
        }
        return false;
    }


    /*
    ACTIVATING SOMETHING WHEN 'ENTER' IS PRESSED.
     */
    public void search (){
        searchText.setOnKeyListener(new View.OnKeyListener(){
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if((keyEvent.getAction() == KeyEvent.ACTION_DOWN) && (i==KeyEvent.KEYCODE_ENTER)){
                    String searchWord =  searchText.getText().toString();
                    /*
                    Add KEY to the searchWord.
                     */
                    searchWord = "videoName="+searchWord;
                    try{
                        url = new URL ("http://10.10.17.236:9898/enjoy/searchVideo");
                    } catch (MalformedURLException e){

                    }

                    try{
                        connection = (HttpURLConnection)url.openConnection();
                        if(connection != null){
                            connection.setConnectTimeout(5000);
                            connection.setUseCaches(false);
                            connection.setRequestMethod("POST");
                            connection.setRequestProperty("Accept-Charset","UTF-8");
                            connection.setRequestProperty("Context_Type","application/x-www-form-urlencoded;charset=UTF-8");

                            OutputStream os = connection.getOutputStream();
                            os.write(searchWord.getBytes("UTF-8"));
                            os.flush();
                            os.close();

                            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                                String line;
                                String page = "";
                                while ((line = reader.readLine()) != null){
                                    page += line;
                                }
                                jsonParse(page);
                            }
                        }
                    } catch (Exception e){

                    } finally {
                        if(connection!=null){
                            connection.disconnect();
                        }
                    }

                    return true;
                }
                return false;
            }
        });
    }


    /*
    CHECK IF THE DIVICE ID EXIST IN DB.
     */
    public void checkingId(){
        String id =  Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        /*
        Add KEY to the id.
         */
        id = "id="+id;
        try{
            url = new URL ("http://10.10.17.236:9898/enjoy/checkId");
        } catch (MalformedURLException e){
            e.printStackTrace();
        }

        try{
            connection = (HttpURLConnection)url.openConnection();
            if(connection != null){
                connection.setConnectTimeout(10000);
                connection.setUseCaches(false);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Accept-Charset","UTF-8");
                connection.setRequestProperty("Context_Type","application/x-www-form-urlencoded;charset=UTF-8");

                OutputStream os = connection.getOutputStream();
                os.write(id.getBytes("UTF-8"));
                os.flush();
                os.close();

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";
                    while ((line = reader.readLine()) != null){
                        page += line;
                    }

                    Toast.makeText(this,page,Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            if(connection!=null){
                connection.disconnect();
            }
            Toast.makeText(MainActivity.this,"Welcome to 2DForAll.",Toast.LENGTH_LONG).show();
        }
    }

    /*
    LOAD LIST OF ALL CLIPS FROM DB
     */
    public void loadAllVideo(){
        try{
            url = new URL ("http://10.10.17.236:9898/enjoy/loadAllVideo");
        } catch (MalformedURLException e){
            e.printStackTrace();
        }

        try{
            connection = (HttpURLConnection) url.openConnection();

            if(connection != null){
                connection.setConnectTimeout(5000);	//연결제한시간. 0은 무한대기.
                connection.setUseCaches(false);		//캐쉬 사용여부
                connection.setRequestProperty("Accept-Charset", "UTF-8"); // Accept-Charset 설정.
                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";

                    while ((line = reader.readLine()) != null){
                        page += line;
                    }
                    /*
                    Recall all the video's information using jsonParse(page).
                     */

                    jsonParse(page);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            if(connection != null){
                connection.disconnect();
            }
        }

    }


    /*
    LOAD BOOKMARK
     */
    public void bookMark(){
        try{
            url = new URL ("http://10.10.17.236:9898/enjoy/getFavourite");
        } catch (MalformedURLException e){

        }

        try{
            connection = (HttpURLConnection) url.openConnection();

            if(connection != null){
                connection.setConnectTimeout(5000);	//연결제한시간. 0은 무한대기.
                connection.setUseCaches(false);		//캐쉬 사용여부
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Accept-Charset", "UTF-8"); // Accept-Charset 설정.
                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";

                    while ((line = reader.readLine()) != null){
                        page += line;
                    }
                     /*
                    Recall user's bookmark information using BookMarkJsonParse(page).
                     */
                    bookMarkJsonParse(page);
                }
            }
        }catch (Exception e){

        } finally {
            if(connection != null){
                connection.disconnect();
            }
        }

    }


    /*
    LOAD HISTORY
     */
    public void history(){
        try{
            url = new URL ("http://10.10.17.236:9898/enjoy/getHistory");
        } catch (MalformedURLException e){

        }

        try{
            connection = (HttpURLConnection) url.openConnection();

            if(connection != null){
                connection.setConnectTimeout(5000);	//연결제한시간. 0은 무한대기.
                connection.setUseCaches(false);		//캐쉬 사용여부
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Accept-Charset", "UTF-8"); // Accept-Charset 설정.
                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";

                    while ((line = reader.readLine()) != null){
                        page += line;
                    }
                     /*
                    Recall user's history information using  HistoryJsonParse(page).
                     */
                    historyJsonParse(page);
                }
            }
        }catch (Exception e){

        } finally {
            if(connection != null){
                connection.disconnect();
            }
        }
    }

    /*
    LOAD GENRE
     */
    public void genre(String genre){
        try{
            url = new URL ("http://10.10.17.236:9898/enjoy/sortByGenre");
        } catch (MalformedURLException e){

        }

        try{
            connection = (HttpURLConnection) url.openConnection();

            if(connection != null){
                connection.setConnectTimeout(5000);	//연결제한시간. 0은 무한대기.
                connection.setUseCaches(false);		//캐쉬 사용여부
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Accept-Charset", "UTF-8"); // Accept-Charset 설정.
                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");

                OutputStream os = connection.getOutputStream();
                os.write(genre.getBytes("UTF-8"));
                os.flush();
                os.close();

                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                    String line;
                    String page = "";

                    while ((line = reader.readLine()) != null){
                        page += line;
                    }
                     /*
                    sort the videos by genre jsonParse(page).
                     */

                    jsonParse(page);
                }
            }
        }catch (Exception e){

        } finally {
            if(connection != null){
                connection.disconnect();
            }
        }

    }

    /*
    JSONPARSE for All Video & Searching Video
     */
    public void jsonParse(String page){
        JSONArray jarray = null;
        JSONObject item = null;
        list.removeAllViews();
        try {
            jarray = new JSONArray(page);
            for (int i = 0; i < jarray.length(); i++) {
                item = jarray.getJSONObject(i);
                Log.i("IMAGE",item.getString("videoThumbnail"));
                /*
                Get the path of the video.
                 */
                final String videoPath = item.getString("videoSource");
                final String videoNumber = String.valueOf(item.getInt("videoNum"));
                /*
                Create new LinearLayout for the loaded videos.
                 */
                LinearLayout videoList =  new LinearLayout(list.getContext());
                videoList.setOrientation(LinearLayout.HORIZONTAL);
                videoList.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

                /*
                Attach thumbnail of the video
                 */
                ImageView videoImg = new ImageView(videoList.getContext());
                int ImageViewWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 320, getResources().getDisplayMetrics());
                int ImageViewHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 180, getResources().getDisplayMetrics());
                videoImg.setLayoutParams(new ViewGroup.LayoutParams(ImageViewWidth,ImageViewHeight));
                Bitmap thumbnail = getImageBitmap(item.getString("videoThumbnail"));
                videoImg.setImageBitmap(thumbnail);
                videoImg.setOnClickListener(new ImageView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        intent.putExtra("videoNum",videoNumber);
                        startActivity(intent);

                    }
                });
                videoList.addView(videoImg);

                /*
                Set the size of the textview, and attach this to the LinearLayout 'videoList'.
                 */
                LinearLayout.LayoutParams parameter = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                parameter.weight = 1;

                TextView videoTitle = new TextView(videoList.getContext());
                videoTitle.setLayoutParams(parameter);
                videoTitle.setPadding(20,0,0,0);
                videoTitle.setText(item.getString("videoName"));
                videoTitle.setTextColor(Color.BLACK);
                videoTitle.setOnClickListener(new TextView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        intent.putExtra("videoNum",videoNumber);
                        startActivity(intent);
                    }
                });
                videoList.addView(videoTitle);

                /*
                Attach button for bookmarking the video.
                 */
                int buttonWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int buttonHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int textsize = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5, getResources().getDisplayMetrics());
                final String videoNum = "videoNum="+String.valueOf(item.getInt("videoNum"));

                Button button = new Button(videoList.getContext());
                button.setLayoutParams(new LinearLayout.LayoutParams(buttonWidth, buttonHeight));
                button.setText("+");
                button.setBackgroundColor(Color.parseColor("#eafffa"));
                button.setTextSize(textsize);
                button.setOnClickListener(new View.OnClickListener() {
                /*
                When the button is clicked, add the video's inforamtion to the current user's bookmark DB.
                 */
                    @Override
                    public void onClick(View view) {
                        try {
                            url = new URL("http://10.10.17.236:9898/enjoy/addFavourite");
                        } catch (MalformedURLException e) {

                        }

                        try {
                            connection = (HttpURLConnection) url.openConnection();
                            if (connection != null) {
                                connection.setConnectTimeout(10000);
                                connection.setUseCaches(false);
                                connection.setRequestMethod("POST");
                                connection.setRequestProperty("Accept-Charset", "UTF-8");
                                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");
                                OutputStream os = connection.getOutputStream();
                                os.write(videoNum.getBytes("UTF-8"));
                                os.flush();
                                os.close();

                                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                                    String line;
                                    String page = "";
                                    while ((line = reader.readLine()) != null) {
                                        page += line;
                                    }

                                    Toast.makeText(MainActivity.this, page, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (Exception e) {

                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }
                });

                videoList.addView(button);
                /*
                Display all the views attached to the videoList.
                 */
                list.addView(videoList);
            }
            /*
            Show message if no videos are found.
             */
            notFound(item);

        } catch (JSONException e) {

        }
    }

    /*
    JSONPARSE for bookMark.
     */
    public void bookMarkJsonParse(String page){
        JSONArray jarray = null;
        JSONObject item = null;
        list.removeAllViews();
        try {
            jarray = new JSONArray(page);
            for (int i = 0; i < jarray.length(); i++) {
                item = jarray.getJSONObject(i);

                /*
                Get the path of the video.
                 */
                final String videoPath = item.getString("videoSource");

                /*
                Create new LinearLayout for the loaded videos.
                 */
                LinearLayout videoList =  new LinearLayout(list.getContext());
                videoList.setOrientation(LinearLayout.HORIZONTAL);
                videoList.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

                /*
                Attach thumbnail of the video
                 */
                ImageView videoImg = new ImageView(videoList.getContext());
                int ImageViewWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 320, getResources().getDisplayMetrics());
                int ImageViewHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 180, getResources().getDisplayMetrics());
                videoImg.setLayoutParams(new ViewGroup.LayoutParams(ImageViewWidth,ImageViewHeight));
                Bitmap thumbnail = getImageBitmap(item.getString("videoThumbnail"));
                videoImg.setImageBitmap(thumbnail);
                videoImg.setOnClickListener(new ImageView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        startActivity(intent);

                    }
                });
                videoList.addView(videoImg);

                /*
                Set the size of the textview, and attach this to the LinearLayout 'videoList'.
                 */
                LinearLayout.LayoutParams parameter = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                parameter.weight = 1;

                TextView videoTitle = new TextView(videoList.getContext());
                videoTitle.setLayoutParams(parameter);
                videoTitle.setPadding(20,0,0,0);
                videoTitle.setText(item.getString("videoName"));
                videoTitle.setTextColor(Color.BLACK);
                videoTitle.setOnClickListener(new TextView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        startActivity(intent);
                    }
                });
                videoList.addView(videoTitle);

                /*
                Attach button for bookmarking the video.
                 */
                int buttonWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int buttonHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int textsize = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5, getResources().getDisplayMetrics());
                final String videoNum = "videoNum="+String.valueOf(item.getInt("videoNum"));

                Button button = new Button(videoList.getContext());
                button.setLayoutParams(new LinearLayout.LayoutParams(buttonWidth, buttonHeight));
                button.setTextSize(textsize);
                button.setText("X");
                button.setBackgroundColor(Color.parseColor("#ffdecf"));
                button.setOnClickListener(new View.OnClickListener() {
                    /*
                    When the button is clicked, add the video's inforamtion to the current user's bookmark DB.
                     */
                    @Override
                    public void onClick(View view) {

                        try {
                                url = new URL("http://10.10.17.236:9898/enjoy/deleteFavourite");
                        } catch (MalformedURLException e) {

                        }

                        try {
                            connection = (HttpURLConnection) url.openConnection();
                            if (connection != null) {
                                connection.setConnectTimeout(10000);
                                connection.setUseCaches(false);
                                connection.setRequestMethod("POST");
                                connection.setRequestProperty("Accept-Charset", "UTF-8");
                                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");
                                OutputStream os = connection.getOutputStream();
                                os.write(videoNum.getBytes("UTF-8"));
                                os.flush();
                                os.close();

                                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                                    String line;
                                    String page = "";
                                    while ((line = reader.readLine()) != null) {
                                        page += line;
                                    }

                                    Toast.makeText(MainActivity.this, page, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (Exception e) {

                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                        /*
                        refresh the screen of the bookmark.
                         */
                        bookMark();
                    }
                });

                videoList.addView(button);
                /*
                Display all the views attached to the videoList.
                 */
                list.addView(videoList);
            }
            /*
            Show message if no videos are found.
             */
            notFound(item);

        } catch (JSONException e) {

        }
    }

    /*
    JSONPARSE for history.
     */
    public void historyJsonParse(String page){
        JSONArray jarray = null;
        JSONObject item = null;
        list.removeAllViews();
        try {
            jarray = new JSONArray(page);
            for (int i = 0; i < jarray.length(); i++) {
                item = jarray.getJSONObject(i);

                /*
                Get the path of the video.
                 */
                final String videoPath = item.getString("videoSource");

                /*
                Create new LinearLayout for the loaded videos.
                 */
                LinearLayout videoList =  new LinearLayout(list.getContext());
                videoList.setOrientation(LinearLayout.HORIZONTAL);
                videoList.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

                /*
                Attach thumbnail of the video
                 */
                ImageView videoImg = new ImageView(videoList.getContext());
                int ImageViewWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 320, getResources().getDisplayMetrics());
                int ImageViewHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, 180, getResources().getDisplayMetrics());
                videoImg.setLayoutParams(new ViewGroup.LayoutParams(ImageViewWidth,ImageViewHeight));
                Bitmap thumbnail = getImageBitmap(item.getString("videoThumbnail"));
                videoImg.setImageBitmap(thumbnail);
                videoImg.setOnClickListener(new ImageView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        startActivity(intent);

                    }
                });
                videoList.addView(videoImg);

                /*
                Set the size of the textview, and attach this to the LinearLayout 'videoList'.
                 */
                LinearLayout.LayoutParams parameter = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                parameter.weight = 1;

                TextView videoTitle = new TextView(videoList.getContext());
                videoTitle.setLayoutParams(parameter);
                videoTitle.setPadding(20,0,0,0);
                videoTitle.setText(item.getString("videoName"));
                videoTitle.setTextColor(Color.BLACK);
                videoTitle.setOnClickListener(new TextView.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, SubActivity.class);
                        intent.putExtra("videoPath", videoPath);
                        startActivity(intent);
                    }
                });
                videoList.addView(videoTitle);

                /*
                Attach button for bookmarking the video.
                 */
                int buttonWidth = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int buttonHeight = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, getResources().getDisplayMetrics());
                int textsize = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5, getResources().getDisplayMetrics());
                final String videoNum = "videoNum="+String.valueOf(item.getInt("videoNum"));

                Button button = new Button(videoList.getContext());
                button.setLayoutParams(new LinearLayout.LayoutParams(buttonWidth, buttonHeight));
                button.setTextSize(textsize);
                button.setText("X");
                button.setBackgroundColor(Color.parseColor("#eee1ff"));

                button.setOnClickListener(new View.OnClickListener() {
                    /*
                    When the button is clicked, add the video's inforamtion to the current user's bookmark DB.
                     */
                    @Override
                    public void onClick(View view) {

                        try {
                            url = new URL("http://10.10.17.236:9898/enjoy/deleteHistory");
                        } catch (MalformedURLException e) {

                        }

                        try {
                            connection = (HttpURLConnection) url.openConnection();
                            if (connection != null) {
                                connection.setConnectTimeout(10000);
                                connection.setUseCaches(false);
                                connection.setRequestMethod("POST");
                                connection.setRequestProperty("Accept-Charset", "UTF-8");
                                connection.setRequestProperty("Context_Type", "application/x-www-form-urlencoded;charset=UTF-8");
                                OutputStream os = connection.getOutputStream();
                                os.write(videoNum.getBytes("UTF-8"));
                                os.flush();
                                os.close();

                                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

                                    String line;
                                    String page = "";
                                    while ((line = reader.readLine()) != null) {
                                        page += line;
                                    }

                                    Toast.makeText(MainActivity.this, page, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (Exception e) {

                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                        /*
                        refresh the screen of history
                         */
                        history();
                    }
                });

                videoList.addView(button);
                /*
                Display all the views attached to the videoList.
                 */
                list.addView(videoList);

            }
            /*
            Show message if no videos are found.
             */
            notFound(item);

        } catch (JSONException e) {

        }
    }


    /*
    PROCESSING IMAGE FILE, FROM FILE PATH, TO A BITMAP
     */
    private Bitmap getImageBitmap(String url) {
        Bitmap bm = null;
        try {
            URL aURL = new URL(url);
            URLConnection conn = aURL.openConnection();
            conn.connect();
            InputStream is = conn.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is);
            bm = BitmapFactory.decodeStream(bis);
            bis.close();
            is.close();
        } catch (IOException e) {
            Log.i("BITMAP FUNCTION :::", "Error getting bitmap", e);
        }
        return bm;
    }

    /*
    Show message for no found results.
     */
    public void notFound(JSONObject item){
        if(item == null){
            int messageTextSize = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12, getResources().getDisplayMetrics());
            TextView message = new TextView(MainActivity.this);
            LinearLayout.LayoutParams messageLayout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
            message.setLayoutParams(messageLayout);
            message.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            message.setText("\n\n\n\n\n\nNO VIDEOS FOUND.\n\n\n\n\n\n");
            message.setTextColor(Color.BLACK);
            message.setTextSize(messageTextSize);
            list.addView(message);
        }
    }
}

